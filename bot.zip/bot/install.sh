apt update && apt upgrade
apt install wget
apt install ffmpeg
apt install nodejs
npm i -g cwebp
npm i -g ytdl 
npm i
npm i got
